﻿namespace Recruits.API.Models
{
    public class Tokens
    {
        public string Token { get; set; } = String.Empty;
        public string RefreshToken { get; set; } = String.Empty;
    }
}
