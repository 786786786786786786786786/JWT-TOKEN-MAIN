﻿namespace Recruits.API.Models
{
    public class Users
    {
        public string Name { get; set; } = String.Empty;
        public string Password { get; set; } = String.Empty;
    }
}
